export class Post{
    title: string;
    content: string;
    loveIts: number
    created_at: Date; 
}